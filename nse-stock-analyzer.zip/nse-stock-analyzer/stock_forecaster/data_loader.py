
import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient
import pandas as pd
from datetime import datetime, timedelta

def get_stock_data(symbol, start_date=None, end_date=None):
    client = ApiClient()
    
    if end_date is None:
        end_date = datetime.now()
    if start_date is None:
        start_date = end_date - timedelta(days=2*365) # At least 2 years of data

    period1 = int(start_date.timestamp())
    period2 = int(end_date.timestamp())

    try:
        response = client.call_api(
            'YahooFinance/get_stock_chart',
            query={
                'symbol': symbol,
                'interval': '1d',  # Daily interval
                'period1': str(period1),
                'period2': str(period2),
                'includeAdjustedClose': True
            }
        )
        
        chart_data = response.get('chart', {}).get('result', [])
        if not chart_data:
            print(f"No data found for {symbol}")
            return pd.DataFrame()

        timestamps = chart_data[0]['timestamp']
        quotes = chart_data[0]['indicators']['quote'][0]
        adjclose = chart_data[0]['indicators']['adjclose'][0]['adjclose']

        data = pd.DataFrame({
            'Open': quotes['open'],
            'High': quotes['high'],
            'Low': quotes['low'],
            'Close': quotes['close'],
            'Volume': quotes['volume'],
            'Adj Close': adjclose
        }, index=pd.to_datetime(timestamps, unit='s'))
        
        data.index.name = 'Date'
        data = data.dropna() # Drop rows with any missing values
        return data

    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")
        return pd.DataFrame()

if __name__ == '__main__':
    # Example usage:
    # Fetch data for Apple (AAPL) for the last 2 years
    aapl_data = get_stock_data('AAPL')
    if not aapl_data.empty:
        print("AAPL Data Head:")
        print(aapl_data.head())
        print("AAPL Data Info:")
        print(aapl_data.info())

    # Fetch data for Google (GOOG) for a specific period
    # start = datetime(2023, 1, 1)
    # end = datetime(2024, 1, 1)
    # goog_data = get_stock_data('GOOG', start_date=start, end_date=end)
    # if not goog_data.empty:
    #     print("\nGOOG Data Head:")
    #     print(goog_data.head())



