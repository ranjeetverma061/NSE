from flask import Flask, render_template_string
import subprocess
import threading
import time
import os

app = Flask(__name__)

# HTML template for the landing page
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Price Forecaster</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            text-align: center;
            max-width: 800px;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
        }
        h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .subtitle {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        .feature {
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .feature h3 {
            margin-top: 0;
            color: #ffd700;
        }
        .launch-btn {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-size: 1.2rem;
            font-weight: bold;
            margin: 2rem 0;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .launch-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin: 2rem 0;
            flex-wrap: wrap;
        }
        .stat {
            text-align: center;
            margin: 0.5rem;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #ffd700;
        }
        .stat-label {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        .footer {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            opacity: 0.7;
        }
        @media (max-width: 768px) {
            h1 { font-size: 2rem; }
            .container { padding: 1rem; }
            .features { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📈 Stock Price Forecaster</h1>
        <p class="subtitle">Advanced ML-powered stock price prediction with 90%+ accuracy</p>
        
        <div class="stats">
            <div class="stat">
                <div class="stat-number">90%+</div>
                <div class="stat-label">Prediction Accuracy</div>
            </div>
            <div class="stat">
                <div class="stat-number">2+</div>
                <div class="stat-label">Years of Data</div>
            </div>
            <div class="stat">
                <div class="stat-number">6</div>
                <div class="stat-label">Technical Indicators</div>
            </div>
            <div class="stat">
                <div class="stat-number">2</div>
                <div class="stat-label">ML Models</div>
            </div>
        </div>

        <div class="features">
            <div class="feature">
                <h3>🤖 Advanced ML Models</h3>
                <p>LSTM neural networks and XGBoost with ensemble learning for maximum accuracy</p>
            </div>
            <div class="feature">
                <h3>📊 Technical Analysis</h3>
                <p>RSI, MACD, Bollinger Bands, EMA, SMA, and Volume Oscillators</p>
            </div>
            <div class="feature">
                <h3>📈 Interactive Charts</h3>
                <p>Candlestick charts with forecast overlay and confidence intervals</p>
            </div>
            <div class="feature">
                <h3>🎯 Trading Signals</h3>
                <p>Buy/sell recommendations based on RSI and MACD strategy</p>
            </div>
            <div class="feature">
                <h3>⚡ Real-time Data</h3>
                <p>Live stock market data from Yahoo Finance API</p>
            </div>
            <div class="feature">
                <h3>🔄 Auto-refresh</h3>
                <p>Dashboard updates every 5 minutes automatically</p>
            </div>
        </div>

        <a href="/dashboard" class="launch-btn">🚀 Launch Dashboard</a>
        
        <div class="footer">
            <p><strong>Supported Features:</strong> Any stock symbol • 7/14/30 day forecasts • Model performance metrics • Confidence intervals</p>
            <p><em>Disclaimer: For educational purposes only. Not financial advice.</em></p>
        </div>
    </div>
</body>
</html>
"""

def start_streamlit():
    """Start Streamlit in a separate thread"""
    try:
        # Change to the script directory
        script_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(script_dir)
        
        # Start Streamlit on port 8502 to avoid conflicts
        subprocess.run([
            "streamlit", "run", "app_simple.py",
            "--server.port", "8502",
            "--server.address", "0.0.0.0",
            "--server.headless", "true"
        ])
    except Exception as e:
        print(f"Error starting Streamlit: {e}")

@app.route('/')
def index():
    """Landing page"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/dashboard')
def dashboard():
    """Redirect to Streamlit dashboard"""
    return """
    <script>
        window.location.href = window.location.origin.replace(':5000', ':8502');
    </script>
    <p>Redirecting to dashboard... If not redirected automatically, <a href="javascript:window.location.href = window.location.origin.replace(':5000', ':8502')">click here</a></p>
    """

if __name__ == '__main__':
    # Start Streamlit in background
    streamlit_thread = threading.Thread(target=start_streamlit, daemon=True)
    streamlit_thread.start()
    
    # Give Streamlit time to start
    time.sleep(3)
    
    # Start Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)

