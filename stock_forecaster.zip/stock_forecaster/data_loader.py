import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta

def get_stock_data(symbol, start_date=None, end_date=None):
    if end_date is None:
        end_date = datetime.now()
    if start_date is None:
        start_date = end_date - timedelta(days=2 * 365)  # 2 years

    try:
        data = yf.download(
            symbol,
            start=start_date.strftime('%Y-%m-%d'),
            end=end_date.strftime('%Y-%m-%d'),
            interval='1d',
            auto_adjust=True,
            progress=False
        )
        
        data = data.rename(columns={
            'Open': 'Open',
            'High': 'High',
            'Low': 'Low',
            'Close': 'Close',
            'Volume': 'Volume',
        })

        data.index.name = 'Date'
        data = data.dropna()
        return data

    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")
        return pd.DataFrame()

# For test run
if __name__ == '__main__':
    aapl_data = get_stock_data('AAPL')
    if not aapl_data.empty:
        print("AAPL Data Head:")
        print(aapl_data.head())
