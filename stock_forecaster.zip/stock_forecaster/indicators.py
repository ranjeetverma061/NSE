import pandas as pd
import pandas_ta as ta

def calculate_indicators(df):
    # Ensure the DataFrame has the required columns
    if not all(col in df.columns for col in ['Open', 'High', 'Low', 'Close', 'Volume']):
        raise ValueError("DataFrame must contain 'Open', 'High', 'Low', 'Close', 'Volume' columns.")

    # RSI (Relative Strength Index)
    df["RSI"] = ta.rsi(df["Close"], length=14)

    # MACD (Moving Average Convergence Divergence)
    macd = ta.macd(df["Close"], fast=12, slow=26, signal=9)
    if macd is not None and not macd.empty:
        # Check available columns in MACD result
        macd_cols = macd.columns.tolist()
        print(f"MACD columns: {macd_cols}")
        
        # Use the actual column names
        if len(macd_cols) >= 3:
            df["MACD"] = macd.iloc[:, 0]  # First column is usually MACD
            df["MACD_Signal"] = macd.iloc[:, 2]  # Third column is usually signal
            df["MACD_Hist"] = macd.iloc[:, 1]  # Second column is usually histogram
        else:
            df["MACD"] = None
            df["MACD_Signal"] = None
            df["MACD_Hist"] = None

    # Bollinger Bands
    bbands = ta.bbands(df["Close"], length=20, std=2.0)
    df["BBL"] = bbands["BBL_20_2.0"]
    df["BBM"] = bbands["BBM_20_2.0"]
    df["BBU"] = bbands["BBU_20_2.0"]
    df["BBB"] = bbands["BBB_20_2.0"]
    df["BBP"] = bbands["BBP_20_2.0"]

    # EMA (Exponential Moving Average)
    df["EMA_10"] = ta.ema(df["Close"], length=10)
    df["EMA_20"] = ta.ema(df["Close"], length=20)
    df["EMA_50"] = ta.ema(df["Close"], length=50)
    df["EMA_200"] = ta.ema(df["Close"], length=200)

    # SMA (Simple Moving Average)
    df["SMA_10"] = ta.sma(df["Close"], length=10)
    df["SMA_20"] = ta.sma(df["Close"], length=20)
    df["SMA_50"] = ta.sma(df["Close"], length=50)
    df["SMA_200"] = ta.sma(df["Close"], length=200)

    # Volume Oscillators (using default parameters for now, can be adjusted)
    # This is a common way to calculate Volume Oscillator, but pandas_ta doesn't have a direct 'VO' function.
    # We can approximate it or use a different library if a specific definition is required.
    # For now, let's use a simple volume moving average difference as an approximation.
    df["VO_short_term_MA"] = ta.sma(df["Volume"], length=14)
    df["VO_long_term_MA"] = ta.sma(df["Volume"], length=28)
    df["Volume_Oscillator"] = ((df["VO_short_term_MA"] - df["VO_long_term_MA"]) / df["VO_long_term_MA"]) * 100

    return df

if __name__ == '__main__':
    # Example Usage:
    # Create a dummy DataFrame for testing
    import numpy as np
    
    # Generate 100 data points
    n_points = 100
    base_price = 100
    
    # Generate realistic stock data
    np.random.seed(42)
    price_changes = np.random.normal(0, 2, n_points)
    prices = [base_price]
    
    for change in price_changes[1:]:
        new_price = prices[-1] + change
        prices.append(max(new_price, 1))  # Ensure price doesn't go negative
    
    # Create OHLC data
    opens = prices[:-1]
    closes = prices[1:]
    highs = [max(o, c) + np.random.uniform(0, 2) for o, c in zip(opens, closes)]
    lows = [min(o, c) - np.random.uniform(0, 2) for o, c in zip(opens, closes)]
    volumes = np.random.randint(100000, 1000000, len(opens))
    
    data = {
        'Open': opens,
        'High': highs,
        'Low': lows,
        'Close': closes,
        'Volume': volumes
    }
    
    # Create a date range for the index
    dates = pd.date_range(start='2023-01-01', periods=len(data['Open']), freq='D')
    df = pd.DataFrame(data, index=dates)
    df.index.name = 'Date'

    print("Original DataFrame Head:")
    print(df.head())

    df_with_indicators = calculate_indicators(df.copy())

    print("\nDataFrame with Indicators Head:")
    print(df_with_indicators.head())
    print("\nDataFrame with Indicators Tail:")
    print(df_with_indicators.tail())
    print("\nDataFrame with Indicators Info:")
    print(df_with_indicators.info())

    # Check for NaN values introduced by indicator calculations
    print("\nNaN values after indicator calculation:")
    print(df_with_indicators.isnull().sum())


