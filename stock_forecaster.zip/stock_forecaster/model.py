
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split, KFold, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import xgboost as xgb

def preprocess_data(df):
    # Fill missing values (forward fill then backward fill)
    df = df.fillna(method='ffill').fillna(method='bfill')

    # Remove outliers (simple IQR method for numerical columns)
    for col in df.select_dtypes(include=np.number).columns:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df[col] = np.where(df[col] < lower_bound, lower_bound, df[col])
        df[col] = np.where(df[col] > upper_bound, upper_bound, df[col])

    # Normalize data (MinMaxScaler)
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df)
    df_scaled = pd.DataFrame(scaled_data, columns=df.columns, index=df.index)

    return df_scaled, scaler

def create_sequences(data, sequence_length):
    X, y = [], []
    for i in range(len(data) - sequence_length):
        X.append(data.iloc[i:(i + sequence_length)].values)
        y.append(data.iloc[i + sequence_length]['Close'])
    return np.array(X), np.array(y)

def build_lstm_model(input_shape):
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(LSTM(units=50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(units=1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

def train_lstm_model(X_train, y_train, epochs=50, batch_size=32):
    model = build_lstm_model((X_train.shape[1], X_train.shape[2]))
    early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2, callbacks=[early_stopping], verbose=0)
    return model, history

def train_xgboost_model(X_train, y_train, params=None):
    if params is None:
        params = {
            'objective': 'reg:squarederror',
            'n_estimators': 100,
            'learning_rate': 0.1,
            'max_depth': 5,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'random_state': 42
        }
    model = xgb.XGBRegressor(**params)
    model.fit(X_train, y_train)
    return model

def evaluate_model(y_true, y_pred):
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mape = mean_absolute_percentage_error(y_true, y_pred) * 100
    r2 = r2_score(y_true, y_pred)
    return rmse, mape, r2

def k_fold_cross_validation(model_type, df_scaled, sequence_length=60, n_splits=5):
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    rmse_scores, mape_scores, r2_scores = [], [], []

    data_for_sequences = df_scaled.copy()
    
    # For XGBoost, we need to flatten the sequences or use direct features
    # For simplicity, let's use the last value of the sequence as the target for XGBoost
    # and the sequence itself as features.
    # This needs careful consideration for feature engineering for XGBoost.
    # For now, let's use a simplified approach for XGBoost where we predict the next close price
    # based on current features.

    if model_type == 'LSTM':
        X, y = create_sequences(data_for_sequences, sequence_length)
        
        for train_index, val_index in kf.split(X):
            X_train, X_val = X[train_index], X[val_index]
            y_train, y_val = y[train_index], y[val_index]

            model, _ = train_lstm_model(X_train, y_train)
            y_pred = model.predict(X_val).flatten()
            rmse, mape, r2 = evaluate_model(y_val, y_pred)
            rmse_scores.append(rmse)
            mape_scores.append(mape)
            r2_scores.append(r2)

    elif model_type == 'XGBoost':
        # For XGBoost, let's use a simpler approach for now: predict next day's close based on current day's features
        # This requires shifting the target variable.
        df_xgb = df_scaled.copy()
        df_xgb["target"] = df_xgb["Close"].shift(-1) # Predict next day's close
        df_xgb = df_xgb.dropna()

        X_xgb = df_xgb.drop("target", axis=1)
        y_xgb = df_xgb["target"]

        for train_index, val_index in kf.split(X_xgb):
            X_train, X_val = X_xgb.iloc[train_index], X_xgb.iloc[val_index]
            y_train, y_val = y_xgb.iloc[train_index], y_xgb.iloc[val_index]

            model = train_xgboost_model(X_train, y_train)
            y_pred = model.predict(X_val)
            rmse, mape, r2 = evaluate_model(y_val, y_pred)
            rmse_scores.append(rmse)
            mape_scores.append(mape)
            r2_scores.append(r2)

    return np.mean(rmse_scores), np.mean(mape_scores), np.mean(r2_scores)

def hyperparameter_tuning_xgboost(X_train, y_train):
    param_grid = {
        'n_estimators': [100, 200, 300],
        'learning_rate': [0.01, 0.1, 0.2],
        'max_depth': [3, 5, 7],
        'subsample': [0.7, 0.8, 0.9],
        'colsample_bytree': [0.7, 0.8, 0.9]
    }
    model = xgb.XGBRegressor(objective='reg:squarederror', random_state=42)
    grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=3, n_jobs=-1, verbose=0, scoring='neg_mean_squared_error')
    grid_search.fit(X_train, y_train)
    return grid_search.best_estimator_, grid_search.best_params_


if __name__ == '__main__':
    # Dummy data for testing
    data = {
        'Open': np.random.rand(200) * 100 + 100,
        'High': np.random.rand(200) * 100 + 105,
        'Low': np.random.rand(200) * 100 + 95,
        'Close': np.random.rand(200) * 100 + 100,
        'Volume': np.random.rand(200) * 100000 + 100000
    }
    df = pd.DataFrame(data)

    # Preprocess data
    df_scaled, scaler = preprocess_data(df.copy())
    print("Preprocessed Data Head:")
    print(df_scaled.head())

    # Test LSTM model
    sequence_length = 10
    X, y = create_sequences(df_scaled, sequence_length)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print("\nTraining LSTM Model...")
    lstm_model, lstm_history = train_lstm_model(X_train, y_train)
    lstm_preds = lstm_model.predict(X_test).flatten()
    rmse_lstm, mape_lstm, r2_lstm = evaluate_model(y_test, lstm_preds)
    print(f"LSTM - RMSE: {rmse_lstm:.4f}, MAPE: {mape_lstm:.2f}%, R2: {r2_lstm:.4f}")

    # Test XGBoost model
    print("\nTraining XGBoost Model...")
    # For XGBoost, we need to prepare data differently (no sequences for simple prediction)
    df_xgb = df_scaled.copy()
    df_xgb["target"] = df_xgb["Close"].shift(-1) # Predict next day's close
    df_xgb = df_xgb.dropna()

    X_xgb = df_xgb.drop("target", axis=1)
    y_xgb = df_xgb["target"]

    X_train_xgb, X_test_xgb, y_train_xgb, y_test_xgb = train_test_split(X_xgb, y_xgb, test_size=0.2, random_state=42)
    
    xgb_model = train_xgboost_model(X_train_xgb, y_train_xgb)
    xgb_preds = xgb_model.predict(X_test_xgb)
    rmse_xgb, mape_xgb, r2_xgb = evaluate_model(y_test_xgb, xgb_preds)
    print(f"XGBoost - RMSE: {rmse_xgb:.4f}, MAPE: {mape_xgb:.2f}%, R2: {r2_xgb:.4f}")

    # Test K-Fold Cross Validation
    print("\nRunning K-Fold Cross Validation for LSTM...")
    mean_rmse_lstm_kf, mean_mape_lstm_kf, mean_r2_lstm_kf = k_fold_cross_validation('LSTM', df_scaled, sequence_length=10)
    print(f"LSTM K-Fold CV - Mean RMSE: {mean_rmse_lstm_kf:.4f}, Mean MAPE: {mean_mape_lstm_kf:.2f}%, Mean R2: {mean_r2_lstm_kf:.4f}")

    print("\nRunning K-Fold Cross Validation for XGBoost...")
    mean_rmse_xgb_kf, mean_mape_xgb_kf, mean_r2_xgb_kf = k_fold_cross_validation('XGBoost', df_scaled)
    print(f"XGBoost K-Fold CV - Mean RMSE: {mean_rmse_xgb_kf:.4f}, Mean MAPE: {mean_mape_xgb_kf:.2f}%, Mean R2: {mean_r2_xgb_kf:.4f}")

    # Test Hyperparameter Tuning for XGBoost
    print("\nRunning Hyperparameter Tuning for XGBoost...")
    best_xgb_model, best_xgb_params = hyperparameter_tuning_xgboost(X_train_xgb, y_train_xgb)
    print(f"Best XGBoost Params: {best_xgb_params}")
    tuned_xgb_preds = best_xgb_model.predict(X_test_xgb)
    rmse_tuned_xgb, mape_tuned_xgb, r2_tuned_xgb = evaluate_model(y_test_xgb, tuned_xgb_preds)
    print(f"Tuned XGBoost - RMSE: {rmse_tuned_xgb:.4f}, MAPE: {mape_tuned_xgb:.2f}%, R2: {r2_tuned_xgb:.4f}")



