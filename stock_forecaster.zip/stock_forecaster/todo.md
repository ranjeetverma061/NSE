# To-Do List for Stock Price Forecasting Application

## Phase 1: Search for APIs and set up project structure
- [x] Search for Yahoo Finance API.
- [x] Create project directory.
- [x] Create `data_loader.py`
- [x] Create `indicators.py`
- [x] Create `model.py`
- [x] Create `app.py`
- [x] Create `requirements.txt`

## Phase 2: Implement data fetching and technical indicators
- [x] Implement data fetching from Yahoo Finance API in `data_loader.py`.
- [x] Implement technical indicators (RSI, MACD, Bollinger Bands, EMA, SMA, Volume Oscillators) in `indicators.py`.

## Phase 3: Build and train ML models with optimization
- [x] Preprocess data (fill missing values, remove outliers, normalize).
- [x] Implement LSTM model.
- [x] Implement XGBoost model.
- [ ] Implement ensemble learning (optional).
- [x] Implement k-fold cross-validation.
- [x] Implement hyperparameter optimization (GridSearchCV or Bayesian Optimization).

## Phase 4: Create Streamlit dashboard with charts and UI
- [x] Design Streamlit UI for stock symbol search and forecast window selection.
- [x] Display candlestick chart with forecast overlay and confidence intervals.
- [x] Display last updated time, forecast confidence score, and model performance metrics (RMSE, MAPE, R²).
- [x] Implement buy/sell signals based on predicted price and RSI/MACD strategy.
- [x] Auto-refresh dashboard every 5 minutes.

## Phase 5: Test application locally and optimize performance
- [x] Test data fetching and indicator calculations.
- [x] Test model training and prediction accuracy.
- [x] Test Streamlit dashboard functionality.
- [x] Optimize overall application performance.

## Phase 6: Deploy application to production
- [x] Prepare deployment script/instructions.
- [x] Deploy the application.


